package com.allaboutscala.chapter1.tutorial_04

object HelloWorldwithArguments extends App {
  println("We are inside Hello World with Arguments")

  println(args.mkString(","))
}
