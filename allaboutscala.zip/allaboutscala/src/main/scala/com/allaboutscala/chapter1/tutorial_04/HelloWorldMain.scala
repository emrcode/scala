package com.allaboutscala.chapter1.tutorial_04

object HelloWorldMain {
  def main(args: Array[String]): Unit = {
     println("Hello World from Main")
  }
}
