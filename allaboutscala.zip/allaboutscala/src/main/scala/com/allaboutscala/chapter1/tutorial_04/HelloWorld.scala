package com.allaboutscala.chapter1.tutorial_04

object HelloWorld extends App {
  println("Hello World!")
}
